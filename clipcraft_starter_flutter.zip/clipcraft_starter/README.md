# ClipCraft — Flutter starter project

This starter is an Android-first UI prototype for a video and photo editor.

## Included now
- Dark purple app design with Edit, Templates, AI Studio and Settings tabs
- Pick a local video and preview/play/pause it
- Feature screens/cards for cut/trim, merge, music/SFX, text/stickers, filters/effects,
  slow motion, transitions, AI editing and HD/4K export settings

## Important status
This is a starter UI, not a finished editor. Actual cutting/merging, audio mixing,
rendering, transitions, photo enhancement and 4K export require a native media
processing engine and device testing. AI features require a secure backend/API.
Do not put private API keys inside the mobile app.

## Run
1. Install Flutter SDK and Android Studio.
2. Unzip this project.
3. In the project folder run:
   - `flutter pub get`
   - `flutter run`
4. Connect an Android phone with USB debugging enabled, or use an emulator.

## Build Android release
- Configure your app ID, signing key and app icon.
- Run `flutter build appbundle --release`
- Upload the generated `.aab` through Google Play Console internal testing first.

Before public release, add a privacy policy, data safety disclosures, permission
justifications, content rating, store listing graphics, and test on real devices.
Use only music, stickers, fonts and templates you have rights to distribute.
