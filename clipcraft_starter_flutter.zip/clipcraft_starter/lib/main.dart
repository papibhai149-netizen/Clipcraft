import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const ClipCraftApp());

const purple = Color(0xFF9B6BFF);
const background = Color(0xFF0B0A10);
const surface = Color(0xFF191722);

class ClipCraftApp extends StatelessWidget {
  const ClipCraftApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ClipCraft',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
      useMaterial3: true,
    ),
    home: const EditorScreen(),
  );
}

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  int selectedTab = 0;
  String? selectedVideo;
  VideoPlayerController? video;
  bool busy = false;

  Future<void> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    setState(() { busy = true; });
    await video?.dispose();
    try {
      final next = VideoPlayerController.file(File(path));
      await next.initialize();
      if (!mounted) { await next.dispose(); return; }
      setState(() {
        video = next;
        selectedVideo = path;
        busy = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => busy = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Video open nahi hua: $e')),
      );
    }
  }

  @override
  void dispose() {
    video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_editorHome(), _templates(), _aiTools(), _settings()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ClipCraft', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          TextButton.icon(
            onPressed: pickVideo,
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Import'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(child: pages[selectedTab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: (v) => setState(() => selectedTab = v),
        backgroundColor: surface,
        indicatorColor: purple.withValues(alpha: .25),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.movie_outlined), label: 'Edit'),
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Templates'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'AI Studio'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _editorHome() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [Color(0xFF8E59FF), Color(0xFF39216D)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CREATE. EDIT. SHINE.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          SizedBox(height: 7),
          Text('Videos, reels and photos — all in one studio.'),
          SizedBox(height: 14),
          Row(children: [Icon(Icons.auto_awesome, size: 30), SizedBox(width: 8), Text('Your creative studio')]),
        ]),
      ),
      const SizedBox(height: 18),
      const _Heading('Your video'),
      const SizedBox(height: 10),
      _preview(),
      const SizedBox(height: 20),
      const _Heading('Video editing'),
      const SizedBox(height: 10),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.65,
        children: const [
          _FeatureTile(Icons.content_cut, 'Cut & trim', 'Trim and split clips'),
          _FeatureTile(Icons.call_merge, 'Merge videos', 'Join multiple clips'),
          _FeatureTile(Icons.music_note, 'Music & sounds', 'Add audio tracks'),
          _FeatureTile(Icons.text_fields, 'Text & stickers', 'Titles and overlays'),
          _FeatureTile(Icons.filter_vintage, 'Filters & effects', 'Color and visual looks'),
          _FeatureTile(Icons.slow_motion_video, 'Slow motion', 'Change clip speed'),
          _FeatureTile(Icons.transition_fade, 'Transitions', 'Smooth scene changes'),
          _FeatureTile(Icons.high_quality, 'HD / 4K export', 'Resolution options'),
        ],
      ),
      const SizedBox(height: 18),
      const _Heading('Photo studio'),
      const SizedBox(height: 10),
      const _FeatureTile(Icons.photo_size_select_actual, '4K photo tools', 'Photo enhancement and export'),
      const SizedBox(height: 18),
      const _Heading('AI studio'),
      const SizedBox(height: 10),
      const _FeatureTile(Icons.auto_awesome, 'AI video editing', 'Auto-edit ideas and smart tools'),
      const SizedBox(height: 6),
      const Text('Note: This starter includes the app design and video import/preview. Editing, AI processing and final 4K rendering need dedicated media-engine integrations.', style: TextStyle(color: Colors.white54, fontSize: 11)),
    ],
  );

  Widget _preview() {
    if (busy) return const Card(child: Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator())));
    if (video != null && video!.value.isInitialized) {
      return Card(
        clipBehavior: Clip.antiAlias,
        child: Column(children: [
          AspectRatio(aspectRatio: video!.value.aspectRatio, child: VideoPlayer(video!)),
          Row(children: [
            IconButton(
              onPressed: () => setState(() => video!.value.isPlaying ? video!.pause() : video!.play()),
              icon: Icon(video!.value.isPlaying ? Icons.pause : Icons.play_arrow),
            ),
            const Expanded(child: Text('Video preview')),
            IconButton(onPressed: pickVideo, icon: const Icon(Icons.swap_horiz)),
          ]),
        ]),
      );
    }
    return InkWell(
      onTap: pickVideo,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white12)),
        child: const Row(children: [
          CircleAvatar(backgroundColor: Color(0x338E59FF), child: Icon(Icons.add, color: Colors.white)),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Start a new project', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 4),
            Text('Tap to choose a video from your phone', style: TextStyle(fontSize: 12, color: Colors.white60)),
          ])),
          Icon(Icons.chevron_right),
        ]),
      ),
    );
  }

  Widget _templates() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      _Heading('Trending templates'),
      SizedBox(height: 8),
      Text('Starter template gallery — add licensed music, clips and template assets before publishing.', style: TextStyle(color: Colors.white60)),
      SizedBox(height: 14),
      _TemplateTile('Cinematic travel reel', 'Travel • 15 sec', Icons.landscape),
      _TemplateTile('Photo beat sync', 'Photo montage • 10 sec', Icons.photo_library_outlined),
      _TemplateTile('Slow-motion moments', 'Slow motion • 20 sec', Icons.slow_motion_video),
      _TemplateTile('Birthday memories', 'Celebration • 30 sec', Icons.celebration_outlined),
    ],
  );

  Widget _aiTools() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      _Heading('AI Studio'),
      SizedBox(height: 8),
      Text('AI features are planned for the next build. A secure backend and model/API integration will be needed.', style: TextStyle(color: Colors.white60)),
      SizedBox(height: 12),
      _TemplateTile('Auto video edit', 'Create a cut from selected clips', Icons.auto_awesome),
      _TemplateTile('Auto captions', 'Generate subtitles from speech', Icons.subtitles_outlined),
      _TemplateTile('Background tools', 'Background remove / replace', Icons.layers_outlined),
      _TemplateTile('Smart photo enhance', 'Photo enhancement workflow', Icons.hdr_auto),
    ],
  );

  Widget _settings() => ListView(
    padding: const EdgeInsets.all(16),
    children: const [
      _Heading('Export settings'),
      SizedBox(height: 10),
      _TemplateTile('Resolution', '720p • 1080p • 4K (when supported)', Icons.high_quality),
      _TemplateTile('Frame rate', '24 • 30 • 60 FPS (when supported)', Icons.speed),
      _TemplateTile('Privacy policy', 'Required before Play Store release', Icons.privacy_tip_outlined),
      _TemplateTile('About ClipCraft', 'Starter version 1.0', Icons.info_outline),
    ],
  );
}

class _Heading extends StatelessWidget {
  final String title;
  const _Heading(this.title);
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _FeatureTile(this.icon, this.title, this.subtitle);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(17)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: const Color(0xFFC6AEFF), size: 22),
      const SizedBox(height: 7),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.white60)),
    ]),
  );
}

class _TemplateTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  const _TemplateTile(this.title, this.subtitle, this.icon);
  @override
  Widget build(BuildContext context) => Card(
    color: surface,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      leading: CircleAvatar(backgroundColor: const Color(0x338E59FF), child: Icon(icon, color: Colors.white)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right),
    ),
  );
}
